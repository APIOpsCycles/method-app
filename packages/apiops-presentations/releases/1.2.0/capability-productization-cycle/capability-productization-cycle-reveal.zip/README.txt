APIOps Cycles Reveal.js edition

Serve this folder with a static HTTP server and open index.html. For example: npx serve .
Use arrow keys, Esc for overview, F for fullscreen and S for speaker notes. Speaker view requires HTTP and popups.
Text, lists and tables are HTML; diagrams and illustrations are image assets.
To change content or branding consistently across formats, edit the source kit and rebuild.
Retain APIOps Cycles, canvas and case-study attribution. Reveal.js is MIT licensed; its notice is in vendor/LICENSE-reveal.txt.
